1/ The project Name is :Peddy - Pet Adoption Platform


2/ Hello ! This is a Pet Adoption Platform . In This PlatForm you can see all our awesome pet collection and you can adopt them also. you can like the pet whice one you loved. Our  site is super fast and seo friendly website


3/ 
<ul>
    <ol>The page is fully seo friendly And responsive</ol>
    <ol>You can Adopt Them</ol>
    <ol>Your will see full details of a pet</ol>
    <ol>You can like a pet whice one you loved</ol>
    <ol>You will se all pet with sort by price</ol>
<ul>



4/ 
